SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* ------------------------------------------ */
/* BEGIN SECTION: Memory performance counters */
/* ------------------------------------------ */

SELECT  object_name as [Object Name] ,
			instance_name AS [Instance Name] ,
			CASE WHEN counter_name = N'Page life expectancy' THEN N'Page life expectancy (seconds)' 
			ELSE counter_name END AS [Counter Name] ,
			cntr_value AS [Value]
	FROM    sys.dm_os_performance_counters
	WHERE   (object_name LIKE N'%Buffer Manager%'
			 AND counter_name = N'Page life expectancy'
			)
			OR (OBJECT_NAME LIKE N'%Memory Manager%')
	ORDER BY object_name ASC ,
			counter_name DESC
	OPTION (RECOMPILE)


/* ------------------------------------------ */
/* END SECTION: Memory performance counters	  */
/* ------------------------------------------ */