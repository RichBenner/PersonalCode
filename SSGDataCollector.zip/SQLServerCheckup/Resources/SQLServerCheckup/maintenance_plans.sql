SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
DECLARE @StringToExecute NVARCHAR(4000);

/* Skip these checks on Azure SQL DB since we can't see system objects or jobs */
IF SERVERPROPERTY('EngineEdition') IN (5, 6, 8)
    BEGIN
    SELECT null AS name, null AS id, null AS owner, null AS Subplan_Count, null AS avg_runtime_seconds, null AS failures, null AS maintenance_plan_steps;
    SELECT null AS name, null AS is_enabled, null AS owner_name, null AS shortest_duration, null AS longest_duration, null AS last_run_date, null AS next_run_date,
           null AS frequency, null AS schedule, null AS schedule_detail, null AS job_success, null AS job_cancel, null AS job_retry, null AS job_fail,
           null AS last_failure_date, null AS operator_id_emailed, null AS log_when, null AS email_when, null AS operator_name, null AS operator_email_address, null AS is_operator_enabled;
    RETURN;
    END

/* Skip these checks on Amazon RDS since we won't have permission to read the log */
IF LEFT(CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS VARCHAR(8000)), 8) = 'EC2AMAZ-'
	AND LEFT(CAST(SERVERPROPERTY('MachineName') AS VARCHAR(8000)), 8) = 'EC2AMAZ-'
	AND LEFT(CAST(SERVERPROPERTY('ServerName') AS VARCHAR(8000)), 8) = 'EC2AMAZ-'
	AND db_id('rdsadmin') IS NOT NULL
	AND SERVERPROPERTY('EngineEdition') NOT IN (5, 6, 8) /* Azure */
	BEGIN
				/* Double-check for RDS objects. Has to be in dynamic SQL because Azure SQL DB won't let this proc
					compile if it refers to master.sys.all_objects directly. More info: 
					https://github.com/BrentOzarULTD/SQL-Server-First-Responder-Kit/issues/1970
				*/
				CREATE TABLE #IsAmazonRDS(Yes BIT);
				SET @StringToExecute = N'IF EXISTS(SELECT * FROM master.sys.all_objects WHERE name IN (''rds_startup_tasks'', ''rds_help_revlogin'', ''rds_hexadecimal'', ''rds_failover_tracking'', ''rds_database_tracking'', ''rds_track_change'')) INSERT INTO #IsAmazonRDS(Yes) VALUES (1);';
				EXEC(@StringToExecute);
				IF EXISTS(SELECT * FROM #IsAmazonRDS)
                    BEGIN
                    SELECT null AS name, null AS id, null AS owner, null AS Subplan_Count, null AS avg_runtime_seconds, null AS failures, null AS maintenance_plan_steps;
                    SELECT null AS name, null AS is_enabled, null AS owner_name, null AS shortest_duration, null AS longest_duration, null AS last_run_date, null AS next_run_date,
                           null AS frequency, null AS schedule, null AS schedule_detail, null AS job_success, null AS job_cancel, null AS job_retry, null AS job_fail,
                           null AS last_failure_date, null AS operator_id_emailed, null AS log_when, null AS email_when, null AS operator_name, null AS operator_email_address, null AS is_operator_enabled;
                    RETURN;
                    END
    END


IF OBJECT_ID('tempdb..#jobsteps') IS NOT NULL
DROP TABLE #jobsteps

CREATE TABLE #jobsteps ([name] NVARCHAR(128), maintenance_plan_xml XML);

IF CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')) LIKE '1%'
  EXEC('
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
  INSERT INTO #jobsteps ([name], maintenance_plan_xml)
  SELECT [name],
                CAST(CAST([packagedata] AS VARBINARY(MAX)) AS XML) AS [maintenance_plan_xml]
         FROM [msdb].[dbo].[sysssispackages]
         WHERE [packagetype] = 6;')

/*Maintenance plans*/
EXEC('WITH XMLNAMESPACES (''www.microsoft.com/SqlServer/Dts'' AS [DTS]),
    [maintenance_plan_steps] AS (
         SELECT [name], [maintenance_plan_xml]
         FROM #jobsteps
    ), 
    [maintenance_plan_table] AS (
        SELECT [mps].[name],
               [c].[value](''(@DTS:ObjectName)'', ''NVARCHAR(128)'') AS [step_name]
        FROM [maintenance_plan_steps] [mps]
            CROSS APPLY [maintenance_plan_xml].[nodes](''//DTS:Executables/DTS:Executable'') [t]([c])
        WHERE [c].[value](''(@DTS:ObjectName)'', ''NVARCHAR(128)'') NOT LIKE ''%{%}%''
    ),
    [mp_steps_pretty] AS (
        SELECT DISTINCT [m1].[name] ,
            STUFF((
                  SELECT N'', '' + [m2].[step_name]  
                  FROM  [maintenance_plan_table] AS [m2] 
                  WHERE [m1].[name] = [m2].[name] 
                FOR XML PATH(N'''')), 1, 2, N''''
              ) AS [maintenance_plan_steps]
        FROM [maintenance_plan_table] AS [m1]
    ),
    [mp_info] AS (
        SELECT [plan_id] ,
                AVG(DATEDIFF(SECOND, [start_time], [end_time])) AS [avg_runtime_seconds] ,
                SUM(CASE [succeeded]
                      WHEN 1 THEN 0
                      ELSE 1
                    END) AS [failures]
        FROM [msdb].[dbo].[sysmaintplan_log]
        GROUP BY
            [plan_id] ,
            [succeeded]
     )
     SELECT
        [p].[name] ,
        [p].[id] ,
        [p].[owner] ,
        [cac].[Subplan_Count] ,
        [mp_info].[avg_runtime_seconds] ,
        [mp_info].[failures],
        [msp].[maintenance_plan_steps]
     FROM
        [msdb].[dbo].[sysmaintplan_plans] [p]
        LEFT JOIN [mp_info]
          ON [mp_info].[plan_id] = [p].[id]
        JOIN [mp_steps_pretty] [msp]
          ON [msp].[name] = [p].[name]
        CROSS APPLY ( 
          SELECT
              COUNT(*) AS [Subplan_Count]
          FROM
              [msdb].[dbo].[sysmaintplan_subplans] [sp]
          WHERE
              [p].[id] = [sp].[plan_id] 
    ) [cac];');
