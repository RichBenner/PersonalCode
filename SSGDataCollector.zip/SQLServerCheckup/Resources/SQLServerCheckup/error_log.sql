SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


	/* ---------------------------------------------- */
	/* BEGIN SECTION: Error log */
	/* ---------------------------------------------- */
	
	IF OBJECT_ID('tempdb..#ErrorLog') IS NOT NULL
		BEGIN
			DROP TABLE #ErrorLog
		END

	IF OBJECT_ID('tempdb..#SearchMessages') IS NOT NULL
		BEGIN
			DROP TABLE #SearchMessages
		END

	CREATE TABLE #ErrorLog
     (
         LogDate DATETIME ,
         ProcessInfo NVARCHAR(100) ,
         Text NVARCHAR(4000) 
     ) ;

	 CREATE TABLE #SearchMessages
     (
         Id INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
		 SearchString NVARCHAR(1000),
		 DaysBack NVARCHAR(100),
		 CurrentDate NVARCHAR(100) DEFAULT N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, 1, SYSDATETIME()), 112) + N'"',
		 SearchOrder NVARCHAR(100) DEFAULT N'"DESC"',
		 Command AS CONVERT(NVARCHAR(4000), 
			N'EXEC master.dbo.xp_readerrorlog 0, 1, '
			+ SearchString
			+ N', '
			+ N'" "'
			+ N', '
			+ DaysBack
			+ N', '
			+ CurrentDate
			+ N', '
			+ SearchOrder
			+ N';'
		 )
     ) ;

	 INSERT #SearchMessages ( SearchString, DaysBack )
	 SELECT x.SearchString, x.DaysBack
	 FROM (VALUES
			(N'"I/O is frozen on database"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -2, GETDATE()), 112) + N'"') ,
			(N'"I/O was resumed on database"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -2, GETDATE()), 112) + N'"') ,
			(N'"I/O requests taking longer than"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"A system assertion check has failed"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"SQL Server is terminating because of fatal exception"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -7, GETDATE()), 112) + N'"'),
			(N'"A significant part of sql server process memory has been paged out"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"occurrence(s) of cachestore flush for the"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"This is a severe system-level error condition"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"SQL Server detected a logical consistency-based I/O error"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"This error condition threatens database integrity and must be corrected"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"Run DBCC CHECK"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"Contact Technical Support"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"SQL Server failed with error code"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"The thread pool for Always On Availability Groups"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"New parallel operation cannot be started"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"SQL Server could not spawn"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"SQL Server failed with error code"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"New queries assigned to process on Node"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"All schedulers on Node"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"There was a memory allocation failure"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"SQL Server has insufficient memory"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"SQL Server was unable to run"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"corruption"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"Timeout occurred while waiting for latch"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"yielding"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"FlushCache"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"Time-out occurred while waiting for buffer"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"IOCP"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"detected"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
			(N'"Autogrow of file"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"'),
            (N'"Buffer Pool Scan"', N'"' + CONVERT(NVARCHAR(30), DATEADD(DAY, -30, GETDATE()), 112) + N'"')
		  ) AS x (SearchString, DaysBack);
		  

    /* Skip these checks on Azure SQL DB and Amazon RDS since we won't have permission to read the log */
	IF LEFT(CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS VARCHAR(8000)), 8) <> 'EC2AMAZ-'
		AND LEFT(CAST(SERVERPROPERTY('MachineName') AS VARCHAR(8000)), 8) <> 'EC2AMAZ-'
		AND LEFT(CAST(SERVERPROPERTY('ServerName') AS VARCHAR(8000)), 8) <> 'EC2AMAZ-'
		AND db_id('rdsadmin') IS NULL
		AND SERVERPROPERTY('EngineEdition') NOT IN (5, 6, 8) /* Azure */
        BEGIN
	    DECLARE @Command NVARCHAR(4000);
	    DECLARE result_cursor CURSOR FOR
	    SELECT Command FROM #SearchMessages;

	    OPEN result_cursor;
	    FETCH NEXT FROM result_cursor INTO @Command;
	    WHILE @@FETCH_STATUS = 0
	    BEGIN 
	
		    INSERT #ErrorLog ( LogDate, ProcessInfo, Text )
		    EXEC(@Command);
	
	    FETCH NEXT FROM result_cursor INTO @Command;
	    END;

	    CLOSE result_cursor;
	    DEALLOCATE result_cursor;
        END

	SELECT TOP 10000 el.LogDate, el.ProcessInfo, el.Text FROM #ErrorLog AS el ORDER BY el.LogDate DESC;

	/* -------------------------------------------- */
	/* END SECTION: Error Log */
	/* -------------------------------------------- */
	
