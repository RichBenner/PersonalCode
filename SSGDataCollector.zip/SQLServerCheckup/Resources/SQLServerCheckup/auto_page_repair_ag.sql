SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
DECLARE @StringToExec NVARCHAR(4000);

/* Azure SQL DB: no direct access to this table */
IF SERVERPROPERTY('EngineEdition') IN (5, 6, 8) OR NOT EXISTS(SELECT * FROM sys.all_objects WHERE name = 'dm_hadr_auto_page_repair')
    SET @StringToExec = N'SELECT NULL AS modification_time, NULL AS database_name, NULL AS file_id, NULL AS page_id, NULL AS error_type, NULL AS page_status
  WHERE 1 = 2';
ELSE
    SET @StringToExec = N'SELECT TOP 1000 r.modification_time, d.name AS database_name, r.file_id, r.page_id, r.error_type, r.page_status
    FROM sys.dm_hadr_auto_page_repair r
    INNER JOIN sys.databases d ON r.database_id = d.database_id
    ORDER BY r.modification_time DESC;';

EXEC(@StringToExec);


