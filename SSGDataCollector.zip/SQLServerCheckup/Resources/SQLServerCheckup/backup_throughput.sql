SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @StringToExecute NVARCHAR(4000);



/* ---------------------------------------- */
/* BEGIN SECTION: Backup throughput history */
/* ---------------------------------------- */

/* Azure SQL DB: no direct access to msdb */
IF SERVERPROPERTY('EngineEdition') IN (5, 6, 7)
    SELECT NULL AS Azure WHERE 1 = 2;
ELSE
    BEGIN
    SET @StringToExecute = N'
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	SELECT @@SERVERNAME AS [Server Name] ,
			YEAR(backup_finish_date) AS [Backup Year] ,
			MONTH(backup_finish_date) AS [Backup Month] ,
			CAST(AVG(( backup_size / ( DATEDIFF(ss, bset.backup_start_date, bset.backup_finish_date) ) / 1048576 )) AS INT) AS [Avg MB/Sec] ,
			CAST(MIN(( backup_size / ( DATEDIFF(ss, bset.backup_start_date, bset.backup_finish_date) ) / 1048576 )) AS INT) AS [Min MB/Sec] ,
			CAST(MAX(( backup_size / ( DATEDIFF(ss, bset.backup_start_date, bset.backup_finish_date) ) / 1048576 )) AS INT) AS [Max MB/Sec]
		FROM msdb.dbo.backupset bset
		WHERE bset.type = ''D'' /* full backups only */
			AND bset.backup_size > 5368709120 /* 5GB or larger */
			AND DATEDIFF(ss, bset.backup_start_date, bset.backup_finish_date) > 1 /* backups lasting over a second */
		GROUP BY YEAR(backup_finish_date) ,
			MONTH(backup_finish_date)
		ORDER BY @@SERVERNAME ,
			YEAR(backup_finish_date) DESC ,
			MONTH(backup_finish_date) DESC;';
    EXEC(@StringToExecute);
    END

