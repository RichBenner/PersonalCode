
/* Last startup */
SELECT
    CAST(sqlserver_start_time AS VARCHAR(100)) as Last_Startup,
    CAST(DATEDIFF(hh,sqlserver_start_time,getdate())/24. as numeric (23,2)) AS days_uptime,
    sqlserver_start_time
FROM    sys.dm_os_sys_info;
