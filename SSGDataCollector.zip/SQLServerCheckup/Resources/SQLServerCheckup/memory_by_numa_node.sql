
DECLARE @StringToExecute NVARCHAR(4000), @TableName NVARCHAR(200), @minutes_passed INT, @deep_dive TINYINT;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* How many minutes have we been running? */
IF SERVERPROPERTY('EngineEdition') IN (5, 6, 8)
    SET @TableName = N' dbo.SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_waits w ';
ELSE
    SET @TableName = N' tempdb..SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_waits w ';
SET @StringToExecute = N'SELECT TOP 1 @minutes_passed = DATEDIFF(mi, w.collection_time, GETDATE()) FROM ' + @TableName; 
EXEC sp_executesql @StringToExecute, N'@minutes_passed INT OUTPUT', @minutes_passed = @minutes_passed OUTPUT;
/* End How many minutes have we been running? */


/* Are we doing a deep dive? */
IF SERVERPROPERTY('EngineEdition') = 5
    SET @TableName = N'dbo.SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_deep_dive';
ELSE
    SET @TableName = N'tempdb..SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_deep_dive';
IF OBJECT_ID(@TableName) IS NOT NULL SET @deep_dive = 1 ELSE SET @deep_dive = 0; 
/* End Are we doing a deep dive? */


/* ---------------------------------------------------- */
/* BEGIN SECTION: Buffer page by database, by NUMA node */
/* This only works in SQL Server 2008+                  */
/* ---------------------------------------------------- */

DECLARE @SQLServerProductVersion NVARCHAR(128);
SELECT @SQLServerProductVersion = CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128));
IF (SELECT LEFT(@SQLServerProductVersion,
    CHARINDEX('.',@SQLServerProductVersion,0)-1
    )) > 9
	AND (@minutes_passed < 5 OR @deep_dive = 1)
BEGIN

	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    /*This is run as dynamic SQL as it will not compile on SQL Server 2005. */
    DECLARE @TSQL NVARCHAR(MAX)
    SET @TSQL=N'
	WITH    memory
			  AS (SELECT    CAST(COUNT(*) * 8 / 1024.0 AS NUMERIC(10, 2)) AS [Cached Data MB] ,
							CAST(SUM(CAST(free_space_in_bytes AS BIGINT)) / 1024. / 1024. AS NUMERIC(10, 2)) AS [Free MB] ,
							CASE database_id
							  WHEN 32767 THEN ''ResourceDb''
							  ELSE DB_NAME(database_id)
							END AS [DB Name],
							numa_node
				  FROM      sys.dm_os_buffer_descriptors
				  GROUP BY  DB_NAME(database_id) ,
							database_id,
							numa_node
				 )
	--The detail by database
	SELECT  numa_node as [NUMA Node] ,
			[Cached Data MB] ,
			[Free MB] ,
			CONVERT(NUMERIC(6, 2), ([Free MB] / [Cached Data MB]) * 100) AS [% Free] ,
			[DB Name]
	FROM    memory
	UNION
	--And now the total
	SELECT  numa_node as [NUMA Node],
			SUM([Cached Data MB]) AS [Cached Data MB] ,
			SUM([Free MB]) AS [Free MB] ,
			CONVERT(NUMERIC(6, 2), (100 * SUM(CAST([Free MB] AS BIGINT)) / SUM(CAST([Cached Data MB] AS BIGINT)))) AS [% Free] ,
			N''***ALL DATABASES***'' AS [DB Name]
	FROM    memory
	GROUP BY numa_node
	ORDER BY numa_node, [Cached Data MB] DESC
	OPTION (RECOMPILE);'

    print @TSQL
    EXEC sp_executesql @TSQL	
END
ELSE
	SELECT NULL AS [NUMA Node], NULL AS [Cached Data MB], NULL AS [Free MB], NULL AS [% Free], 'No results for SQL Server 2005 or long-running SQLServerCheckup without --deepdive switch' AS [DB Name];


/* -------------------------------------------------- */
/* END SECTION: Buffer page by database, by NUMA node */
/* -------------------------------------------------- */