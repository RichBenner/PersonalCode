/* ---------------------------------------- */
/* BEGIN SECTION: Plans duplicated in cache */
/* ---------------------------------------- */
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

WITH 
    XMLNAMESPACES 
(
    DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan'
),
    qs AS
(
    
    SELECT
        x.*
    FROM
    (
        SELECT TOP (10)
            qs.query_hash,
            query_stats_rows = SUM(1),
            executions = SUM(qs.execution_count),
            total_logical_reads = SUM(qs.total_logical_reads),
            total_worker_time = SUM(qs.total_worker_time),
            total_elapsed_time = SUM(qs.total_elapsed_time),
            plan_hashes = COUNT(DISTINCT qs.query_plan_hash),
            creation_time_min = MIN(qs.creation_time),
            creation_time_max = MAX(qs.creation_time),
            last_execution_time = MAX(qs.last_execution_time),
            query_plan_worst = 
                (
                    SELECT TOP (1)
                        qpWorst.query_plan
                    FROM sys.dm_exec_query_stats AS qsWorst
                    CROSS APPLY sys.dm_exec_query_plan(qsWorst.plan_handle) AS qpWorst            
                    WHERE qsWorst.query_hash = qs.query_hash
                    ORDER BY 
                        qsWorst.total_logical_reads DESC
                )
        FROM sys.dm_exec_query_stats AS qs
        GROUP BY 
            qs.query_hash
        HAVING COUNT(*) > 10
        ORDER BY 
            query_stats_rows DESC
    ) AS x
    
    UNION ALL
    
    SELECT
        query_hash = NULL,
        query_stats_rows = SUM(1),
        executions = SUM(qsT.execution_count),
        total_logical_reads = SUM(qsT.total_logical_reads),
        total_worker_time = SUM(qsT.total_worker_time),
        total_elapsed_time = SUM(qsT.total_elapsed_time),
        plan_hashes = 0,
        creation_time_min = MIN(qsT.creation_time),
        creation_time_max = MAX(qsT.creation_time),
        last_execution_time = MAX(qsT.last_execution_time),
        query_plan_worst = NULL
    FROM sys.dm_exec_query_stats AS qsT
)
SELECT TOP (11)
    qs.query_hash,
    qs.query_stats_rows,
    qs.executions,
    qs.total_logical_reads,
    qs.total_worker_time,
    qs.total_elapsed_time,
    qs.plan_hashes,
    qs.creation_time_min,
    qs.creation_time_max,
    qs.last_execution_time,
    compile_time_ms = x.c.value('sum(//QueryPlan/@CompileTime)', 'float'),
    compile_cpu_ms = x.c.value('sum(//QueryPlan/@CompileCPU)', 'float'),
    compile_memory_kb = x.c.value('sum(//QueryPlan/@CompileMemory)', 'float'),
    qs.query_plan_worst
FROM qs
OUTER APPLY qs.query_plan_worst.nodes('ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS x(c)
ORDER BY 
    query_stats_rows DESC;

/* -------------------------------------- */
/* END SECTION: Plans duplicated in cache */
/* -------------------------------------- */
