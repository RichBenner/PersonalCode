DECLARE @StringToExecute NVARCHAR(4000), @TableName NVARCHAR(200), @minutes_passed INT, @deep_dive TINYINT;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


/* -------------------------------------------- */
/* BEGIN SECTION: Buffer page usage by database */
/* -------------------------------------------- */

/* How many minutes have we been running? */
IF SERVERPROPERTY('EngineEdition') IN (5, 6, 8)
    SET @TableName = N' dbo.SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_waits w ';
ELSE
    SET @TableName = N' tempdb..SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_waits w ';
SET @StringToExecute = N'SELECT TOP 1 @minutes_passed = DATEDIFF(mi, w.collection_time, GETDATE()) FROM ' + @TableName; 
EXEC sp_executesql @StringToExecute, N'@minutes_passed INT OUTPUT', @minutes_passed = @minutes_passed OUTPUT;
/* End How many minutes have we been running? */


/* Are we doing a deep dive? */
IF SERVERPROPERTY('EngineEdition') = 5
    SET @TableName = N'dbo.SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_deep_dive';
ELSE
    SET @TableName = N'tempdb..SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_deep_dive';
IF OBJECT_ID(@TableName) IS NOT NULL SET @deep_dive = 1 ELSE SET @deep_dive = 0; 
/* End Are we doing a deep dive? */



IF @minutes_passed < 5 OR @deep_dive = 1
	BEGIN
	WITH    memory
			  AS (SELECT    CAST(COUNT(*) * 8 / 1024.0 AS NUMERIC(10, 2)) AS [Cached Data MB] ,
							CAST(SUM(CAST(free_space_in_bytes AS BIGINT)) / 1024. / 1024. AS NUMERIC(10, 2)) AS [Free MB] ,
							CASE database_id
							  WHEN 32767 THEN 'ResourceDb'
							  ELSE DB_NAME(database_id)
							END AS [DB Name]
				  FROM      sys.dm_os_buffer_descriptors
				  GROUP BY  DB_NAME(database_id) ,
							database_id
				 )
	--The detail by database
	SELECT  [Cached Data MB] ,
			[Free MB] ,
			CONVERT(NUMERIC(6, 2), ([Free MB] / [Cached Data MB]) * 100) AS [% Free] ,
			[DB Name]
	FROM    memory
	UNION
	--And now the total
	SELECT  SUM([Cached Data MB]) AS [Cached Data MB] ,
			SUM([Free MB]) AS [Free MB] ,
			CONVERT(NUMERIC(6, 2), (100 * SUM(CAST([Free MB] AS BIGINT)) / SUM(CAST([Cached Data MB] AS BIGINT)))) AS [% Free] ,
			N'***ALL DATABASES***' AS [DB Name]
	FROM    memory
	ORDER BY [Cached Data MB] DESC
	OPTION (RECOMPILE);
	END
ELSE
	BEGIN
	SELECT  0 AS [Cached Data MB] ,
			0 AS [Free MB] ,
			0 AS [% Free] ,
			N'Skipped because SQLServerCheckup took over 5 minutes to run. To gather this data, use the --deepdive configuration switch.' AS [DB Name];
	END

	

/* -------------------------------------------- */
/* END SECTION: Buffer page usage by database   */
/* -------------------------------------------- */