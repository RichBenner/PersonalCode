
IF EXISTS (SELECT * FROM sys.dm_os_performance_counters)
	SELECT
		TOP 1 COALESCE(CAST(SERVERPROPERTY('MachineName') AS NVARCHAR(100)),LEFT(object_name, (CHARINDEX(':', object_name) - 1))) as MachineName,
		ISNULL(CAST(SERVERPROPERTY('InstanceName') AS NVARCHAR(100)),'(default instance)') as InstanceName,
		CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(100)) as ProductVersion,
        CASE WHEN CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(2)) IN ('10', '11', '12', '13')
              AND SERVERPROPERTY('EngineEdition') NOT IN (5, 6, 8)
            THEN CAST(SERVERPROPERTY('ProductLevel') AS NVARCHAR(100)) 
            ELSE ''
        END as PatchLevel,
		CAST(SERVERPROPERTY('Edition') AS VARCHAR(100)) as Edition,
		CAST(SERVERPROPERTY('IsClustered') AS VARCHAR(100)) as IsClustered,
		CAST(COALESCE(SERVERPROPERTY('IsHadrEnabled'),0) AS VARCHAR(100)) as AlwaysOnEnabled,
		'' AS Warning
	FROM sys.dm_os_performance_counters;
ELSE
	SELECT
		TOP 1 (CAST(SERVERPROPERTY('MachineName') AS NVARCHAR(100))) as MachineName,
		ISNULL(CAST(SERVERPROPERTY('InstanceName') AS NVARCHAR(100)),'(default instance)') as InstanceName,
		CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(100)) as ProductVersion,
		CAST(SERVERPROPERTY('ProductLevel') AS NVARCHAR(100)) as PatchLevel,
		CAST(SERVERPROPERTY('Edition') AS VARCHAR(100)) as Edition,
		CAST(SERVERPROPERTY('IsClustered') AS VARCHAR(100)) as IsClustered,
		CAST(COALESCE(SERVERPROPERTY('IsHadrEnabled'),0) AS VARCHAR(100)) as AlwaysOnEnabled,
		'WARNING - No records found in sys.dm_os_performance_counters' AS Warning
