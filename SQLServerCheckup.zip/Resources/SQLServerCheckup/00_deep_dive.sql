DECLARE @StringToExecute NVARCHAR(4000), @TableName NVARCHAR(100), @UseSharedTable BIT = 0;

BEGIN TRY

    /* Azure SQL DB: no direct access to tempdb, so we have to work in the current database */
    IF SERVERPROPERTY('EngineEdition') = 5
        SET @TableName = N'dbo.SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_deep_dive';
    ELSE
        SET @TableName = N'tempdb..SQLServerCheckup_2A98B846_4179_496B_AAF8_60B405E3ED68_deep_dive';
    
    SET @StringToExecute = N'IF OBJECT_ID(''' + @TableName + N''') IS NOT NULL 
            DROP TABLE ' + @TableName + N';
    
        CREATE TABLE ' + @TableName + N'(start_date DATETIME);
        INSERT INTO ' + @TableName + N'(start_date) VALUES (GETDATE());';
    
    EXEC(@StringToExecute);
    
    SELECT @UseSharedTable;

END TRY

BEGIN CATCH

	IF ERROR_NUMBER() = 262 -- 262 CREATE TABLE permission denied
    BEGIN
		SELECT 1;
	
        SELECT GETDATE() AS start_date;
    END
    ELSE
		THROW;
	
END CATCH