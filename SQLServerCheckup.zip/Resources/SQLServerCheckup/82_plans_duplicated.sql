SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

WITH 
    XMLNAMESPACES 
(
    DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan'
),
    RedundantQueries AS
(
    SELECT TOP (10)
        s.query_hash,
        s.statement_start_offset,
        s.statement_end_offset,
        sort_order = COUNT(s.query_hash),
        PlansCached = COUNT(s.query_hash),
        DistinctPlansCached = COUNT(DISTINCT (s.query_hash)),
        FirstPlanCreationTime = MIN(s.creation_time),
        LastPlanCreationTime = MAX(s.creation_time),
        LastExecutionTime = MAX(s.last_execution_time),
        Total_CPU_ms = SUM(s.total_worker_time),
        Total_Duration_ms = SUM(s.total_elapsed_time),
        Total_Reads = SUM(s.total_logical_reads),
        Total_Writes = SUM(s.total_logical_writes),
        Total_Executions = SUM(s.execution_count)
    FROM sys.dm_exec_query_stats AS s
    GROUP BY
        s.query_hash,
        s.statement_start_offset,
        s.statement_end_offset
    HAVING 
        COUNT(s.query_hash) > 10
    ORDER BY 
        sort_order DESC
)
SELECT
    r.query_hash,
    r.PlansCached,
    r.DistinctPlansCached,
    q.SampleQueryText,
    r.Total_Executions,
    r.Total_CPU_ms,
    r.Total_Duration_ms,
    r.Total_Reads,
    r.Total_Writes,
    r.FirstPlanCreationTime,
    r.LastPlanCreationTime,
    r.LastExecutionTime,
    r.statement_start_offset,
    r.statement_end_offset,
    r.sort_order,
    q.compile_time_ms,
    q.compile_cpu_ms,
    q.compile_memory_kb,
    q.SampleQueryPlan
FROM RedundantQueries AS r
CROSS APPLY
(
    SELECT TOP (3)
        SampleQueryText = st.text,
        SampleQueryPlan = qp.query_plan,
        qs.total_elapsed_time,
        compile_time_ms = x.c.value('sum(//QueryPlan/@CompileTime)', 'float'),
        compile_cpu_ms = x.c.value('sum(//QueryPlan/@CompileCPU)', 'float'),
        compile_memory_kb = x.c.value('sum(//QueryPlan/@CompileMemory)', 'float')
    FROM sys.dm_exec_query_stats AS qs
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
    CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
    OUTER APPLY qp.query_plan.nodes('ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS x(c)
    WHERE r.query_hash = qs.query_hash
    AND   r.statement_start_offset = qs.statement_start_offset
    AND   r.statement_end_offset = qs.statement_end_offset
    ORDER BY 
        qs.total_elapsed_time DESC
) AS q
ORDER BY
    r.sort_order DESC,
    r.query_hash,
    r.statement_start_offset,
    r.statement_end_offset,
    q.total_elapsed_time DESC;